export const REGISTER_USER='register-user';
export const CHAT_ROOM='chat-room';
