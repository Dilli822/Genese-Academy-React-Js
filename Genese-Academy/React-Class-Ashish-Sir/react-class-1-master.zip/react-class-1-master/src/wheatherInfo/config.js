export const CONFIG={
    WHETHER_API_KEY:"71fece0c7006618b74e68725dd67d2fd",
    WHETHER_API:
        "http://api.openweathermap.org/data/2.5/weather?q=~&units=metric&appid="
};
